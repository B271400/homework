#!/bin/bash
#$ -cwd -V
#$ -N fixByAWK

./fix.awk ./mock_NCBI.fasta

#$ -o result_awk.fasta
#$ -e error_awk.e
