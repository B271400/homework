#!/bin/bash
#$ -cwd -V
#$ -N FixBySH

./fix.sh ./mock_NCBI.fasta

#$ -o result_sh.fasta
#$ -e error_sh.e
