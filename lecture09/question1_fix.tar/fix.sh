count=0
while read line
do
if [[ ${line:0:1} == ">" ]]
then
	#distinguish the first header
	count=$((count+1))
	if [[ ${count} -eq 1 ]]
	then
		printf ${line}"\n"
	else
		printf "\n"${line}"\n"
	fi
else
	upper_line=$(echo "${line}" | tr "a-z" "A-Z")
	printf ${upper_line}
fi
done < $1
